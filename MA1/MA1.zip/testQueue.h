//
// Created by Cameron on 9/13/2020.
//

#ifndef MA1_TESTQUEUE_H
#define MA1_TESTQUEUE_H


#include <iostream>
#include <cstdlib>

using namespace std;

// define default capacity of the queue
#define SIZE 10

// Class for queue
class queue
{
    int* arr;		// array to store queue elements
    int capacity;	// maximum capacity of the queue
    int front;		// front points to front element in the queue (if any)
    int rear;		// rear points to last element in the queue
    int count;		// current size of the queue

public:
    queue(int size = SIZE); 	// constructor
    ~queue();   				// destructor

    void dequeue();
    void enqueue(int x);
    int peek();
    int size();
    bool isEmpty();
    bool isFull();
};

// Class for testQueue
class testQueue
{
public:
    testQueue();

    // Test cases
    void testSize();
    void testIsEmpty();
    void testIsFull();
    void testEQCF();
    void testEQC();
    void testPQCE();
    void testPQC();
    void testDQC();
    void testDQCE();
};
#endif //MA1_TESTQUEUE_H
