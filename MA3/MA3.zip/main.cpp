#include <map>
#include <fstream>
#include <string.h>
#include "TwitterData.hpp"

/*
 * What piece of data read from the file did you use for the key and why?
 * Answer: The username is what I used. It is easier because there cannot be duplicate usernames in the file
 *
 * Assuming that the map is using a red-black tree, what is the worst-case Big-O for inserting key-value pairs based on a key?
 * Answer: Worst case O(log n)
 *
 * Assuming that the map is using a red-black tree, what is the worst-case Big-O for retrieving data based on a key?
 * Answer: Worst case O(log n)
 *
 * Assuming that the map is using a red-black tree, what is the worst-case Big-O for deleting key-value pairs based on a key?
 * Answer: Worst case O(n)
 *
 * Based on the specific algorithm that you used to find and remove a key-value pair based on a value, what is the worst-case Big-O?
 * Answer: Worst case O(n)
 *
 * Based on your conclusions of the tasks that were performed in this assignment, when and why should we use a map?
 * Answer: A map is best when storing information attached to either an index or an id. A map is good at finding this fast.
 *
 * Assuming that the “MostViewedCategory” data in the file represents the kind of Tweets that a particular user views frequently. Is a map an ideal data structure to use to retrieve this information, especially if we want to use the info for advertising? If not, what data structure would you use instead?
 * Answer: I don't think a map is necessarily a bad idea to use. From my knowledge, I believe it is easy to use and implement. However, you could use a different data structure for advertisement. I do not know much about how we could implement advertising with a map, but it seems to be an easy way to access mass amounts of profiles in a quick manner. I personally would use a map if I was doing something of this sort.
 *
 *
 *
 */

// Deserialize
TwitterData* DS(char *token)
{
    token = strtok(token, ",");

    // For last name
    std::string name = token;

    token = strtok(NULL, ",");

    // For first name
    name.append(",").append(token);

    // For email
    std::string email = token;

    token = strtok(NULL, ",");

    // For number of tweets
    std::string str = token;

    int numTweets = stoi(str);

    token = strtok(NULL, ",");

    // For category
    std::string category = token;

    TwitterData *item = new TwitterData();
    item->setActualName(name);
    item->setEmail(name);
    item->setNumTweets(numTweets);
    item->setCategory(category);

    return item;
}

// Loading our data
void load(std::map<std::string, TwitterData*> *map)
{
    std::ifstream file("TwitterAccounts.csv");

    // For info
    char line[256];
    file.getline(line,256);

    while(!file.eof())
    {
        std::string s = line;

        // Checking if the line is empty then skipping
        if(s.empty())
        {
            continue;
        }

        char *token = strtok(line, ",");

        // For username
        std::string username = token;

        token = strtok(NULL, "\"");
        std::string data;

        data.append(token);

        // For twitter data
        TwitterData *parse = DS(token);

        // For putting username oin the data;
        parse->setUserName(username);

        // Inserting to map
        map->insert(std::pair<std::string, TwitterData*>(username, parse));

    }
}

// Printing map
void print(std::map<std::string, TwitterData*> *map)
{
    std::cout << "Printing out map " << std::endl;

    for (std::map<std::string, TwitterData*>::iterator itr = map->begin(); itr != map->end(); itr++)
    {
        TwitterData* data = itr->second;

        std::cout << itr->first << ": " << data->getActualName() << " " << data->getCategory() << " " << data->getEmail() << " " << data->getNumTweets() << std::endl;

    }
}


// Removing by name
void remove(std::map<std::string, TwitterData*> *map, std::string name)
{
    std::map<std::string, TwitterData*>::iterator removing;
    for (std::map<std::string, TwitterData*>::iterator itr = map->begin(); itr != map->end(); itr++)
    {
        if (itr->second->getActualName() == name)
        {
            removing = itr;
        }
    }
    map->erase(removing);
}


int main(int argc, char* argv[])
{
    // we need a map to store our key-value pairs
    // std::map<keyType, ValueType>; What should the key be? What about the value?
    std::map<std::string, TwitterData*> *map = new std::map<std::string, TwitterData*>();

    // Loading data
    load(map);

    // Printing map
    print(map);

    // Remove savage1 from file
    std::map<std::string, TwitterData*>::iterator itr = map->find("savage1");
    delete itr->second;
    map->erase(itr);

    // Printing map
    print(map);

    // Remove name Smith,Rick
    remove(map, "Smith,Rick");

    // Printing map
    print(map);

    // Deleting map
    delete map;


    return 0;
}