//
// Created by Cameron on 9/20/2020.
//

#ifndef PA2_TESTLISTMYJOSEPHUS_H
#define PA2_TESTLISTMYJOSEPHUS_H

#include <iostream>
#include <fstream>
#include "sstream"
#include "ListMyJosephus.h"
#include "StackNode.h"
#include <ctime>

template <class T>
class TestListMyJosephus
{
public:
    TestListMyJosephus();

    // Test cases
    int testLMJ();
    void testLine();
    void testFile();
    void testRun();
    void testElim();
    void testResults();

};

#endif //PA2_TESTLISTMYJOSEPHUS_H
