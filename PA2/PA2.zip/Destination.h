//
// Created by Cameron on 9/19/2020.
//

#ifndef PA2_DESTINATION_H
#define PA2_DESTINATION_H

#include <iostream>

using namespace std;

class Destination
{
private:
    int position;
    int friends;

    string name;

public:

    // Explicit constructor
    explicit Destination(int position, string name);

    // Constructor
    Destination();

    // Destructor
    ~Destination();

    // Gets number of friends
    int getFriends();

    // Gets position
    int getPosition();

    // Gets the name
    string getName();

    // Gets destination
    string getDestination();

    // To print current position
    void printPosition();

    // Prints destination name
    void printDestinationName();
};


#endif //PA2_DESTINATION_H
