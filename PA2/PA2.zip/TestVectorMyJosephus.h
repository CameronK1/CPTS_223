//
// Created by Cameron on 9/20/2020.
//

#ifndef PA2_TESTVECTORMYJOSEPHUS_H
#define PA2_TESTVECTORMYJOSEPHUS_H

class TestVectorMyJosephus
{
public:
    TestVectorMyJosephus();

    // Test cases
    int testVMJ();
    void testVLine();
    void testVFile();
    void testVRun();
    void testVElim();
    void testVResults();
    void runVTestCases();
};

#endif //PA2_TESTVECTORMYJOSEPHUS_H
