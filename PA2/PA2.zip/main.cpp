//
// Created by Cameron on 9/19/2020.
//

#include "TestListMyJosephus.h"
#include "TestVectorMyJosephus.h"

/*
 *  Does the processor of the machine that is running the algorithms matter? Will you receive the same timing statistics on every machine?
 *  The processor of the machine does not matter. However, depending on the processor some will run the algorithms faster than the other.
 *
 *  Which of the two implementations (list vs. vector) performs best and under what conditions? Does it depend on the input?
 *  std::vector will perform much faster under most conditions (especially as time goes on).
 *  Examples: Finding and element, working with very small data, faster to push elements at the back
 *  std::list will perform better at sorting or inserting at the front
 *  std::list also handles large elements better than vector
 *  The input definitely matters. As time goes on vector is increasingly more efficient than list.
 *
 *  How does the running time dependency on the parameter N compare with the dependency on the parameter M?
 *  When M is not changing and we continuously square N, it is drastically shorter than continuously squaring M while N is not changing.
 */


int main()
{
    TestListMyJosephus<class T> test1 = TestListMyJosephus<class T>();
    TestVectorMyJosephus test2 = TestVectorMyJosephus();

    return 0;
}
