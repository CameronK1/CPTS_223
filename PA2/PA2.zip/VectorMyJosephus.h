//
// Created by Cameron on 9/19/2020.
//

#ifndef PA2_VECTORMYJOSEPHUS_H
#define PA2_VECTORMYJOSEPHUS_H

#include <iostream>
#include <vector>
#include <string>
#include "fstream"


using namespace std;

class VectorMyJosephus
{
private:
    int M;
    int N;


    vector<int> v;
    vector<string> vDestinations;

public:
    // Explicit constructor
    explicit VectorMyJosephus(int M, int N);

    // Constructor
    VectorMyJosephus();

    // Destructor
    ~VectorMyJosephus();

    // Makes sequence empty
    void clear();

    // Checks size
    int currentSize();

    // Returns if there are no destinations in the sequence
    bool isEmpty();

    // Eliminates destination based on simulation rules
    void eliminateDestination();

    // Prints all destinations left
    void printAllDestinations();

    // Loads destinations
    void loadDestinations();


};


#endif //PA2_VECTORMYJOSEPHUS_H
