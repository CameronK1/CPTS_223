//
// Created by Cameron on 9/19/2020.
//

#ifndef PA2_STACKNODE_H
#define PA2_STACKNODE_H

#include <iostream>
#include <list>

using namespace std;

template <class T>
class StackNode
{
private:
    StackNode<T> *next = nullptr;
    T data;

public:
    // Getting the next node
    StackNode<T> *getNext();

    // Getting the data
    T getData();

    // Setting the next node
    void setNext(StackNode<T> *next);

    // Setting data
    void setData(T update);
};

template <class T>
StackNode<T> *StackNode<T>::getNext()
{
    return next;
}

template <class T>
void StackNode<T>::setNext(StackNode<T> *next)
{
    this->next = next;
}

template <class T>
T StackNode<T>::getData()
{
    return data;
}

template<class T>
void StackNode<T>::setData(T update)
{
    data = update;
}

template <class T>
class Stack
{
private:
    StackNode<T> *head = nullptr;
public:
    Stack<T>()
    {

    }

    // Setting the head
    void setHead(StackNode<T> *newHead);

    T top();

    // Pushing
    void push(T item);

    // Popping
    void pop();

    // Returns if empty
    bool isEmpty();

    // Getting size
    int getSize();

};

template <class T>
void Stack<T>::setHead(StackNode<T> *newHead)
{
    head = newHead;
}

template <class T>
T Stack<T>::top()
{
    return head->getData();
}

template <class T>
void Stack<T>::push(T item)
{
    // Node allocation
    auto *newNode = new StackNode<T>;
    newNode->setData(item);

    // Checking if empty, then setting it to head
    if (isEmpty())
    {
        setHead(newNode);

        return;
    }

    // Pointing to the next value
    newNode->setNext(head);

    // Setting newNode as the new current head
    setHead(newNode);
}

template <class T>
bool Stack<T>::isEmpty()
{
    return head == nullptr;
}

template <class T>
int Stack<T>::getSize()
{
    int count = 1;

    if (isEmpty())
        return 0;

    StackNode<T> *current = head;
    while (current->getNext() != NULL)
    {
        count++;
        if (current->getNext() !=NULL)
        {
            current = current->getNext();
        }
    }

    return count;
}

#endif //PA2_STACKNODE_H
