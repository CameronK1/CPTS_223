//
// Created by Cameron on 9/19/2020.
//

#ifndef PA2_LISTMYJOSEPHUS_H
#define PA2_LISTMYJOSEPHUS_H

#include "Destination.h"
#include <iostream>
#include <list>

using namespace std;

template <class T>
class ListMyJosephus
{
private:
    T data;
    ListMyJosephus<T> *next = NULL;
    ListMyJosephus<T> *head = NULL;
    int M;
    int N;

    ListMyJosephus<Destination> *destinations = new ListMyJosephus<Destination>();

public:
    // Explicit constructor
    explicit ListMyJosephus(int M, int N);

    // Destructor
    ~ListMyJosephus();

    // Makes sequence empty
    void clear();

    // Checks size
    int currentSize();

    // Returns if there are no destinations in the sequence
    bool isEmpty();

    // Eliminates destination based on simulation rules
    void eliminateDestination(T item);

    // Prints all destinations left
    void printAllDestinations();

    // Inserting the item at the front
    void insertAtFront(T item);

    // Getting the lists head
    ListMyJosephus<T> *getHead();

    // Load from destinations.csv
    void loadDestinations();

    // Getting data stored in the node
    T getData();

    // Get next node pointed to
    ListMyJosephus<T> *getNext();

    // Setting the retrieved data
    void setData(T data);

    // Setting next node pointed to
    void setNext(ListMyJosephus<T> *next);

    // Checking if the node points to another
    bool hasNext();

    // Creating linked list
    ListMyJosephus<T>();
};

#endif //PA2_LISTMYJOSEPHUS_H
