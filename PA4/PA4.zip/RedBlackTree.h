//
// Created by Cameron on 10/16/2020.
//

#ifndef PA4_REDBLACKTREE_H
#define PA4_REDBLACKTREE_H

#include "RedBlackNode.h"

template <class T>
class RedBlackTree
{
private:
    RedBlackNode<T> *root;

public:

    // Constructor
    RedBlackTree();

    // Destructor
    ~RedBlackTree();

    // For rotations/balancing
    void rotateLeft(RedBlackNode<T> *&, RedBlackNode<T> *&);
    void rotateRight(RedBlackNode<T> *&, RedBlackNode<T> *&);
    void balance(RedBlackNode<T> *&, RedBlackNode<T> *&);

    bool isEmpty();

    void insert(const int &item);

    void remove();

    void clear();

    void printInOrder(RedBlackNode<T> *root);

};

template <class T>
bool RedBlackTree<T>::isEmpty()
{
    return root = nullptr;
}

template <class T>
RedBlackTree<T>::RedBlackTree()
{
    root = NULL;
}

// For in order traversal and printing
template <class T>
void RedBlackTree<T>::printInOrder(RedBlackNode<T> *root)
{
    if (root == NULL)
        return;

    inorder(root->left);

    cout << root->data << " " << endl;

    inorder(root->right);
}





#endif //PA4_REDBLACKTREE_H
