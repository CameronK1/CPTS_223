#include <iostream>

int main()
{
/*
 * What is the worst-case Big-O of the insert () algorithm for the red-black tree? Explain.
 * Answer: Worst case: O(log n) because insert() is always O(height of tree) which is always balanced. This means it is O(logn) because a RBT is always balanced.
 *
 * What is the worst-case Big-O of the remove () algorithm for the red-black tree? Explain.
 * Answer: Worst case: O(log n)
 *
 * What is the worst-case Big-O of the clear () algorithm for the red-black tree? Explain.
 * Answer: Worst case: O(log n)
 */

// @TODO Insert code/finished questions/makefile from laptop to pc
    return 0;
}
