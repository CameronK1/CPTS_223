//
// Created by Cameron on 10/16/2020.
//

#ifndef PA4_INVENTORYRECORD_H
#define PA4_INVENTORYRECORD_H

#include <iostream>

using namespace std;

class InventoryRecord
{
private:
    int invID;
    int stock;
    string type;

public:
    InventoryRecord();
    // Explicit constructor
    explicit InventoryRecord(int invID, string type, int stock);
    int getID();
    int getStock();
    string getType();
    ~InventoryRecord() {};

    // Displays the game menu
    void displayMenu();

    // Lets player add an item
    void addItem();

    // Lets player remove an item
    void removeItem();

    // Lets player see the current inventory
    void showInventory();

    void updateItem();

    // Exits
    void exit();
};


#endif //PA4_INVENTORYRECORD_H
