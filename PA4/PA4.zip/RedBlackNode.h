//
// Created by Cameron on 10/16/2020.
//

#ifndef PA4_REDBLACKNODE_H
#define PA4_REDBLACKNODE_H

#include <iostream>

using namespace std;

enum Color {RED, BLACK};

template <class T>
class RedBlackNode
{
private:

    // For whether it is red or black
    bool color;

    T data;

    RedBlackNode<T> *left = NULL;
    RedBlackNode<T> *right = NULL;
    RedBlackNode<T> *parent = NULL;


public:

    // Constructor
    RedBlackNode(T data);

    // Destructor
    ~RedBlackNode();
};

template <class T>
RedBlackNode<T>::RedBlackNode(T data)
{
    this->data = data;
    this->color = RED;

    left = right = parent = NULL;
}

template <class T>
RedBlackNode<T>::~RedBlackNode() {}

#endif //PA4_REDBLACKNODE_H
