#include "BankData.hpp"
#include <cstdlib>
#include <fstream>
#include <unordered_map>
#include <sstream>
#include <iostream>

int BankData::getAcctNum() const
{
	return *(this->mpAcctNum);
}

double BankData::getSavingsAmount() const
{
	return *(this->mpSavingsAmount);
}

double BankData::getCheckingAmount() const
{
	return *(this->mpCheckingAmount);
}

void BankData::setAcctNum(const int& newAcctNum)
{
	// you need to implement
	*(this->mpAcctNum) = newAcctNum;
}

void BankData::setSavingsAmount(const double& newSavingsAmount)
{
	// you need to implement
	*(this->mpSavingsAmount) = newSavingsAmount;
}

void BankData::setCheckingAmount(const double& newCheckingAmount)
{
	// you need to implement
	*(this->mpCheckingAmount) = newCheckingAmount;
}

void BankData::loadPrintBankData()
{
    std::string key;
    double data;
    std::unordered_map<std::string, double> bank;
//    std::pair<std::string,double> items;
    // Insert
    std::ifstream infile("BankAccounts.csv");

    if (!infile.is_open())
    {
        std::exit(EXIT_FAILURE);
    }

    while (std::getline(infile, key))
    {
        std::istringstream iss(key);
        std::string value;
        while (std::getline(iss, value, ','))
        {
            std::cout << value << " " << std::endl;
        }
    }

    bank.insert(std::make_pair(key,data));


    for (auto& item : bank)
    {
        for (int i = 0; i < 1000; i++)
        {std::cout << "Value: " << bank.bucket(item.first) << " is in position: " << i;}
    }
}
