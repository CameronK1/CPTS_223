#include "BankData.hpp"

int main(int argc, char* argv[])
{
/*
 * Assuming that the underlying hash table created cannot be resized, and that the hash function is poor, what is the worst-case Big-O for inserting key-value pairs based on a key? List any other assumptions that you make.
 * Answer: The worst case Big-O would be O(n). Assuming that we have more elements in the same bucket, when we search the list from the bucket and insert at the end it would be O(n) to search and insert.
 *
 * Let’s say that the underlying hash table uses linear probing, what is the worst-case Big-O for retrieving data based on a key? List any assumptions that you make.
 * Answer: The worse case Big-O would be O(n). Since it is linear probing we search until we find the elements.
 *
 * Let’s say the underlying hash table uses chaining, what is the worst-case Big-O for deleting key-value pairs based on a key? List any assumptions that you make.
 * Answer: The worse case Big-O would be O(n). In chaining we need to find the key and delete it.
 *
 * What is the worst-case Big-O for iterating through the entire unordered map? List any assumptions that you make.
 * Answer: The worse case Big-O would be O(n). This is because incrementing an iterator is required to be at a constant time. This means iterating through all the elements would be O(n)
 *
 * Based on your conclusions of the tasks that were performed in this assignment, when and why should we use an unordered map?
 * We should use an unordered map when we need to purely lookup and retrieve elements. Unordered map has a large array that can be used.
 *
 *  Is an std::unordered_map a robust choice for storing, removing, and searching bank accounts? Explain.
 *  It is a robust choice for storing/removing/searching. However, I do not prefer this as it is much easier to use different data structures that could perform this faster and more efficiently/gracefully.
 */
    BankData::loadPrintBankData();

	return 0;
}