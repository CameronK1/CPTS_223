//
// Created by Cameron on 9/1/2020.
//
#include "Node.h"
#include "Game.h"
#include <cstdlib>

void Game::start()
{
    int point = 0;
    int numQuestions = getNumQuestions();

    // Load questions
    Stack<Question> questions = genQuestions(numQuestions);

    for (int i = 0; i < numQuestions; i++)
    {
        // Gets position
        Question question = questions.top();
        questions.pop();

        // Asks player the question
        point += askQuestion(question);
    }

    // Displays the players points
    cout << "Your total points are: " << point << endl;

    // Asks player if they'd like to save their points
    if (askToSave())
        savePoints(point);
}

void Game::displayMenu()
{
    int input = 0;

    while (input != 7)
    {
        cout << "1. Game Rules" << endl;
        cout << "2. Play Game" << endl;
        cout << "3. Load Previous Game" << endl;
        cout << "4. Add Command" << endl;
        cout << "5. Remove Command" << endl;
        cout << "6. Show Commands" << endl;
        cout << "7. Exit" << endl;

        // Store input
        cin >> input;

        // Making sure the input is in bounds
        if (input < 1 || input > 7)
        {
            cout << "Invalid number please enter a number between 1 and 7" << endl;

            continue;
        }

        // Choosing based on input
        if (input == 1)
            gameRules();
        if (input == 2)
            start();
        if (input == 3)
            loadPreviousGame();
        if (input == 4)
            addCommand();
        if (input == 5)
            removeCommand();
        if (input == 6)
            showCommands();
        if (input == 7)
            exit();
    }
}

void Game::addCommand()
{
    string name;
    char description[256];

    // Gets the new name for the command
    cout << "Enter the name of the new command: " << endl;
    cin >> name;

    // Get description of the new command
    cout << "Enter the description of the new command: " << endl;
    cin >> description;

    // Create the new command
    Data item = Data(name,description);
    commands->insertAtFront(item);

    // Pauses the system until user presses a button
    system("pause");
}


void Game::removeCommand()
{
    string name;

    // Prompts user for the command that they want to remove
    cout << "Enter the name of the command to be removed: " << endl;
    cin >> name;

    // For name and description
    Data item = Data(name,"");

    // Removes the node
    commands->removeNode(item);

    // Successfully removed the commands
    cout << "Removed all commands that matched the name:  \"" << name << "\"" << endl;
}

void Game::showCommands() {
    if(commands->isEmpty())
        cout << "No loaded commands" << endl;
    else
    {
        // Get the head
        Node<Data> *current = commands->getHead();

        // As long as current is not null continue
        while (current != nullptr)
        {
            cout << current->getData().getName() << "," << current->getData().getDescription() << '\n' << endl;
            if (current->hasNext())
                current = current->getNext();
            else
                current = nullptr;
        }
    }

    system("pause");
}

void Game::gameRules()
{
    cout << "Game Rules:" << endl << endl;
    cout << "Each player will be given a command with one correct answer and two incorrect answers." << endl;
    cout << "The player must match the command to the correct description by choosing a number 1-3." << endl;
    cout << "For each correct answer 1 point will be awarded." << endl;
    cout << "For each incorrect answer 1 point will be taken away." << endl;
    cout << "Each command will only be displayed one time per game." << endl;
    cout << "The points will be tallied at the end of the game." << endl;

    system("pause");
}

void Game::getPoints()
{
    // Open profiles.csv
    ifstream infile;
    infile.open("profiles.csv");

    // Checking if successfully opened
    if (!infile.is_open())
        cout << "File failed to open" << endl;
    else
    {
        // File line
        string fLine;

        string name;
        string point;

        // Getting each line in the file
        while (getline(infile, fLine))
        {
            int index = 0;

            for (char c : fLine)
            {
                // Checking for commas and splitting
                if (c == ',')
                {
                    break;
                }

                index++;
            }

            // Getting the name of the player
            for (int i = 0; i < index; i++)
            {
                name += fLine[i];
            }

            // Getting the points for each player
            for (int i = index + 1; i < fLine.length(); i++)
            {
                point += fLine[i];
            }

            // Converting a string into and integer
            int actualPoints = stoi(point);

            // Create and save a record
            Record record = {name, actualPoints};
            addRecord(record);
        }
    }

    // Closing infile
    infile.close();
}

void Game::loadCommandsFromFile()
{
    // Open file
    ifstream file("commands.csv");

    // Checking if file was successfully opened
    if(!file.is_open())
    {
        cout << "File failed to open" << endl;
    }
    else
    {
        string line;

        while (getline(file,line))
        {
            // Checking commas and splitting up
            int index = 0;
            for (char c : line)
            {
                if(c == ',')
                {
                    break;
                }
                index++;
            }

            string name;
            string description;

            // Getting the name
            for(int i = 0; i < index; i++)
            {
                name += line[i];
            }

            // Getting the description
            for (int i = index + 1; i < line.length(); i++)
            {
                description += line[i];
            }

            // Saving the data found
            Data found = Data(name, description);
            commands->insertAtFront(found);
        }

        // Close file
        file.close();
    }
}

void Game::loadPreviousGame()
{
    string name;

    // Asking for the name out of profiles.csv
    cout << "Enter the name associated with the previous game: " << endl;
    cin >> name;

    Record record = {name, 0};

    if (!pointsContain(record))
    {
        cout << "The record with the name " << name << " cannot be found" << endl;
        return;
    }
    else
    {
        int index = pointsIndex(record);
        Record real = points[index];

        cout << "Players highscore is: " << real.point << endl;

        system("pause");
        start();
    }
}

int Game::getNumQuestions()
{
    int input = 0;

    while (input < 5 || input > 30)
    {
        cout << "There is a minimum of 5 questions or a maximum of 30 questions." << endl;
        cout << "Enter the number of questions you want to have this game: " << endl;
        cin >> input;
    }

    // Returns the number of questions the player wants
    return input;
}

Stack<Question> Game::genQuestions(int num)
{
    // Create question storage
    Stack<Question> stack = Stack<Question>();

    // Create num of questions needed
    for (int i = 0; i < num; i++)
    {
        int index = rand() % commands->getSize();

        int wrongIndex1 = randIndex(commands->getSize(), index);
        int wrongIndex2 = randIndex(commands->getSize(), index);

        // Getting 3 options
        Data correct = commands->get(index);
        Data wrongOne = commands->get(wrongIndex1);
        Data wrongTwo = commands->get(wrongIndex2);

        // Question object
        Question *question = new Question();

        // Getting names and descriptions for each
        question->command = correct.getName();
        question->correct = correct.getDescription();
        question->wrong = wrongOne.getDescription();
        question->wrong2 = wrongTwo.getDescription();

        // Storing said question
        stack.push(*question);
    }

    // Returns the stack
    return stack;
}

int Game::pointsSize()
{
    for (int i = 0; i < 2048; i++)
    {
        if (points[i].point == NULL)
            return i;
    }

    return 2048;
}

int Game::randIndex(int upLimit, int excludeNum)
{
    // Generates a random item
    int item = rand() % upLimit;

    // Making sure number is able to use
    while (item == excludeNum)
        item = rand() % upLimit;

    return item;
}

int Game::askQuestion(Question question)
{
    int input = 0;
    bool answered = false;

    // Randomize question order
    int randomize = rand() % 3;

    // Make sure input is okay
    while (!answered)
    {
        // Displaying converted question
        cout << question.convertQuestion(randomize) << endl;

        cout << "Choose the correct description (1-3): " <<endl;
        cin >> input;

        if (input < 0 || input > 3)
            continue;
        else
            answered = true;
    }

    // Changing points based on answer
    if (input == question.correctAnswer(randomize))
        return 1;
    else
        return -1;
}

void Game::savePoints(int point)
{
    string name;

    // Users name for saving
    cout << "Enter players name: " << endl;
    cin >> name;

    // Create the new record being saved
    Record *record = new Record();
    record->name = name;
    record->point = point;

    // Storing
    addRecord(*record);
}

bool Game::askToSave()
{
    // Default to not save
    char choice = 'n';

    // Ask if they want to save
    cout << "Would you like to save the score? (y/n)" << endl;
    cin >> choice;

    return (choice == 'y' || choice == 'Y');
}

void Game::saveRecords()
{
    // Open the output
    ofstream outfile;
    outfile.open("profiles.csv");

    // Linked list to store records being saved
    LinkedList<Record> saving = LinkedList<Record>();

    // Searching for highest points
    for (int i = 0; i < pointsSize(); i++)
    {
        // Getting current record
        Record curr = points[i];

        // Getting the highest points for the persons name
        for (int j = 0; j < pointsSize(); j++)
        {
            if (i == j)
                continue;
            Record currHighest = points[j];

            if (curr.name == currHighest.name)
            {
                if (currHighest.point > curr.point)
                    curr.point = currHighest.point;
            }
        }

        // Checking if name already has been changed
        if (!saving.contains(curr))
            saving.insertAtFront(curr);
    }

    for (int i = 0; i < saving.getSize(); i++)
    {
        Record record = saving.get(i);

        // Printing to profile.csv
        outfile << record.name << ',' << record.point << endl;
    }

    // Closing profiles.csv
    outfile.close();
}

int Game::pointsIndex(Record record)
{
    for (int i = 0; i < pointsSize(); i++)
    {
        if (points[i].name == record.name)
            return i;
    }
}

void Game::addRecord(Record record)
{
    int size = pointsSize();
    points[size] = record;
}

void Game::initPoints()
{
    for (int i = 0; i < 2048; i++)
    {
        Record a = {"", NULL};
        points[i] = a;
    }
}

bool Game::pointsContain(Record record)
{
    for (int i = 0; i < pointsSize(); i++)
    {
        if (points[i].name == record.name)
            return i;
    }
}

Game::Game()
{
    loadCommandsFromFile();
    initPoints();
    getPoints();
    displayMenu();
}

void Game::exit()
{
    saveRecords();
}