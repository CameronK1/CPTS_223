//
// Created by Cameron on 9/1/2020.
//

#ifndef INC_223_PA1_GAME_H
#define INC_223_PA1_GAME_H
#include <fstream>
#include <iostream>

#include "Data.h"
#include "Node.h"
#include "List.h"

using namespace std;

// Used for storing the player's points
struct Record
{
    string name;
    int point;

public:
    friend bool operator==(Record one,Record two)
    {
        return one.name == two.name;
    }
};

// Stores the information of the questions that will be prompted
struct Question
{
    string command;
    string correct;
    string wrong;
    string wrong2;

private:

    // Used so players can select what option of the three questions that they have to choose from
    string list(string one, string two, string three)
    {
        // Creating the string
        string item;

        // Appending each
        item.append("1. ").append(one).append("\n");

        item.append("2. ").append(two).append("\n");

        item.append("3. ").append(three).append("\n");

        return item;
    }

public:

    // Converts a question into a string
    // int randomize is used so the question doesn't always stay in the same spot
    string convertQuestion(int randomize)
    {
        string item = "";

        // Setting up the title
        item.append(command);

        item.append("\n");

        if(randomize == 0)
            item.append(list(correct, wrong, wrong2));
        if(randomize == 1)
            item.append(list(wrong,correct, wrong2));
        if(randomize == 2)
            item.append(list(wrong, wrong2, correct));

        return item;
    }

    // To get the correct answer from the randomized spot
    int correctAnswer(int randomize)
    {
        if (randomize == 0)
            return 1;
        if (randomize == 1)
            return 2;
        else
            return 3;
    }
};

// Used to run game
class Game
{
private:
    // For saving how many points the players have
    Record points[2048];

    // For storing all the commands
    LinkedList<Data> *commands = new LinkedList<Data>();

public:
    // Starts the game
    void start();

    // Displays the game menu
    void displayMenu();

    // Lets player add a command to the game
    void addCommand();

    // Lets player remove a command from the game
    void removeCommand();

    // Lets player see all the current commands
    void showCommands();

    // Lets the player view the rules of the game
    void gameRules();

    // Loads the commands from commands.csv
    void loadCommandsFromFile();

    // Lets the player load a previous game they have played before
    void loadPreviousGame();

    // Load the players points from profiles.csv
    void getPoints();

    // Lets player choose how many questions
    int getNumQuestions();

    // Random index for pulling a random question
    int randIndex(int upLimit, int excludeNum);

    // Getting question and option chosen
    int askQuestion(Question question);

    // Saves the players points
    void savePoints(int point);

    // Lets player choose if they would like to save their points
    bool askToSave();

    // Saves all the records/overwrites records
    void saveRecords();

    // Creates a stack of questions that the player will be asked
    Stack<Question> genQuestions(int num);

    // Size of points
    int pointsSize();

    // Gets points index of player
    int pointsIndex(Record record);

    // Adds a record
    void addRecord(Record record);

    // Initializes the points
    void initPoints();

    bool pointsContain(Record record);

    // Lets the player exit the game and save their points
    void exit();

public:
    // Creates game object
    Game();
};

#endif //INC_223_PA1_GAME_H
