//
// Created by Cameron on 9/7/2020.
//

#ifndef INC_223_PA1_LIST_H
#define INC_223_PA1_LIST_H
#include <iostream>

using namespace std;

template <class T>
class Node
{
private:
    T data;
    Node<T> *next = NULL;

public:
    // Getting data stored in the node
    T getData();

    // Get next node pointed to
    Node<T> *getNext();

    // Setting the retrieved data
    void setData(T data);

    // Setting next node pointed to
    void setNext(Node<T> *next);

    // Checking if the node points to another
    bool hasNext();

    // To create a node
    Node<T>();
};

template <class T>
T Node<T>::getData()
{
    return data;
}

template <class T>
Node<T> *Node<T>::getNext()
{
    return next;
}

template <class T>
void Node<T>::setData(T data)
{
    this->data = data;
}

template <class T>
void Node<T>::setNext(Node<T> *next)
{
    this->next = next;
}

template <class T>
bool Node<T>::hasNext()
{
    return next != NULL;
}

template <class T>
Node<T>::Node()
{
    next = nullptr;
}

template <class T>
class LinkedList
{
private:
    Node<T> *head = NULL;

public:
    // Inserting the item at the front
    void insertAtFront(T item);

    // Remove an item from the list
    void removeNode(T item);

    // Checking if there is something stored in the list
    bool contains(T data);

    // Checking if the list is empty
    bool isEmpty();

    // Getting the lists head
    Node<T> *getHead();

    // Getting an items index in the list
    int itemIndex(T data);

    // Getting list size
    int getSize();

    // Get data from index in this list
    T get(int index);

    // Creating linked list
    LinkedList<T>();
};

template <class T>
void LinkedList<T>::insertAtFront(T item)
{
    //Create a new node
    auto *node = new Node<T>();
    node->setData(item);
    node->setNext(NULL);

    //Check if we have an empty linked list
    if (isEmpty())
    {
        head = node;
        return;
    }

    //Map the node to the current head
    node->setNext(head);

    // For setting the new head
    head = node;
}

template <class T>
void LinkedList<T>::removeNode(T item)
{
    bool found = false;
    Node<T> *current = head;
    Node<T> *before = nullptr;

    // Checking if the list is empty
    if(isEmpty())
        return;

    // Do if we want to remove the first node
    if(current->getData() == item)
    {
        if(!current->hasNext())
            head = nullptr;
        else
            head == current->getNext();
        return;
    }

    // Continue to next
    current = current->getNext();

    // Do if we want a different item removed
    if (current->getData() == item)
    {
        // Iteration for the list
        while (!found && current->hasNext())
        {
            // Removing node if it is found
            if (current->getData() == item)
            {
                found = true;

                if (!current->hasNext())
                    before->setNext(nullptr);
                else
                    before->setNext(current->getNext());

            }

            // Item not found
            else
            {
                before = current;
                current = current->getNext();
            }
        }
    }
}

template <class T>
bool LinkedList<T>::contains(T item)
{
    //Define the variables we need
    Node<T> *current = head;

    //Check beginning cases
    if(isEmpty())
        return false;
    if(current->getData() == item)
        return true;

    //Loop
    while (current->hasNext()) {
        if(current->getData() == item)
            return true;
        current = current->getNext();
    }

    return false;
}

template <class T>
bool LinkedList<T>::isEmpty()
{
    return head == nullptr;
}

template <class T>
Node<T> *LinkedList<T>::getHead()
{
    return head;
}

template <class T>
int LinkedList<T>::itemIndex(T data)
{
    int index = 0;

    if (isEmpty())
        return -1;

    Node<T> *current = head;
    while (current != NULL)
    {
        if (current->getData() == data)
        {
            return index;
        }

        index++;
        current = current->getNext();
    }

    return -1;
}

template <class T>
int LinkedList<T>::getSize()
{
    // Count for size
    int count = 0;

    // Checking if it is empty
    // If empty return 0
    if (isEmpty())
        return 0;

    // Setting current to head
    Node<T> *current = head;
    // Looping through it
    while (current != NULL)
    {
        count++;
        current = current->getNext();
    }

    return count;
}

template <class T>
T LinkedList<T>::get(int index)
{
    int currIndex = 0;

    // Checking for issues
    if (isEmpty())
        throw exception();
    if (index < 0)
        throw exception();
    if (index > getSize() - 1)
        throw exception();

    // Getting item based on its index
    Node<T> *current = head;

    while (current != NULL)
    {
        if (currIndex == index)
        {
            return current->getData();
        }
        currIndex++;
        current = current->getNext();
    }

    throw exception();
}

template <class T>
LinkedList<T>::LinkedList()
{

}

#endif //INC_223_PA1_LIST_H
