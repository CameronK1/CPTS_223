//
// Created by Cameron on 9/1/2020.
//
#include "Data.h"

Data::Data(string name, string description)
{
    this->name = name;
    this->description = description;
}

string Data::getName()
{
    return name;
}

string Data::getDescription()
{
    return description;
}

Data::Data() {}

bool operator==(Data lhs, Data rhs)
{
    return lhs.getName() == rhs.getName();
}