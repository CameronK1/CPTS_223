//
// Created by Cameron on 9/1/2020.
//

#ifndef INC_223_PA1_DATA_H
#define INC_223_PA1_DATA_H
#include <iostream>

using namespace std;

class Data {
private:
    string name;
    string description;
public:
    string getName();
    string getDescription();
    Data(string name, string description);
    Data();

    friend bool operator==(Data lhs, Data rhs);
};

#endif //INC_223_PA1_DATA_H
