//
// Created by Cameron on 9/1/2020.
// Credit Jordan M. for help with errors

#include <iostream>
#include "Node.h"
#include "List.h"
#include "Data.h"
#include "Game.h"
#include "time.h"

int main()
{
    /*  ADVANTAGES/DISADVANTAGES LINKED LIST:
     * Advantage: Makes insertion and removal easier
     * Disadvantage: Memory usage increases
     *
     *
     * ADVANTAGES/DISADVANTAGES ARRAY:
     * Advantage: Easy to loop through arrays/takes little memory
     * Disadvantage: Must be a fixed size which can cause issues when not knowing how much space is needed
     * Disadvantage: Leads to unused memory being taken by the array
     */



    srand(time(NULL));
    Game game = Game();

    return 0;
}
